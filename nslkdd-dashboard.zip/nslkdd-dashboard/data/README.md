วางไฟล์ `KDDTrain+.txt` และ `KDDTest+.txt` ไว้ที่นี่ (ถ้าไม่วาง แอปจะดาวน์โหลดจาก
https://github.com/defcom17/NSL_KDD ให้อัตโนมัติตอนรันครั้งแรก)
